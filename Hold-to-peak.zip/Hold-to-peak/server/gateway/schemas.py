from __future__ import annotations

from typing import Any, Dict, List, Literal, Optional
from pydantic import BaseModel, Field


class Span(BaseModel):
    text: str
    bbox: List[float] = Field(default_factory=list)
    conf: float | None = None


class ConversationTurn(BaseModel):
    role: Literal["user", "assistant", "system"]
    content: str


class SolveRequest(BaseModel):
    mode: Literal["auto", "solve", "explain", "translate", "summarize"] = "auto"
    prompt: str = ""
    ocr_text: str = ""
    spans: List[Span] = Field(default_factory=list)
    image_png_b64: Optional[str] = None
    images_png_b64: List[str] = Field(default_factory=list)
    meta: Dict[str, Any] = Field(default_factory=dict)
    history: List[ConversationTurn] = Field(default_factory=list)
    api_key: Optional[str] = None
    model: Optional[str] = None
    stream: bool = True


class ConfigUpdate(BaseModel):
    openrouter_api_key: Optional[str] = None
    default_model: Optional[str] = None
    timeout_seconds: Optional[int] = Field(default=None, ge=30, le=600)
