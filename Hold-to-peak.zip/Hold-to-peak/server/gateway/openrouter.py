from __future__ import annotations

import asyncio
import json
from typing import AsyncIterator, Dict, List, Optional

import httpx

OPENROUTER_CHAT_URL = "https://openrouter.ai/api/v1/chat/completions"


class OpenRouterError(RuntimeError):
    """Raised when the OpenRouter API returns an error response."""


async def stream_chat_completion(
    *,
    client: httpx.AsyncClient,
    api_key: str,
    model: str,
    messages: List[Dict],
    response_format: Optional[Dict] = None,
    timeout: int = 120,
) -> AsyncIterator[Dict]:
    """Yield streamed events from OpenRouter's chat completions endpoint."""

    headers = {
        "Authorization": f"Bearer {api_key}",
        "X-OpenRouter-Model": model,
        "Accept": "text/event-stream",
    }

    payload: Dict = {
        "stream": True,
        "model": model,
        "messages": messages,
    }
    if response_format:
        payload["response_format"] = response_format

    try:
        async with client.stream(
            "POST",
            OPENROUTER_CHAT_URL,
            headers=headers,
            json=payload,
            timeout=timeout,
        ) as response:
            if response.status_code >= 400:
                detail = await response.aread()
                raise OpenRouterError(
                    f"OpenRouter error {response.status_code}: {detail.decode('utf-8', 'ignore')}"
                )

            async for raw_line in response.aiter_lines():
                if not raw_line:
                    continue
                if raw_line.startswith("data: "):
                    data = raw_line.removeprefix("data: ").strip()
                else:
                    data = raw_line.strip()
                if data == "[DONE]":
                    break
                try:
                    event = json.loads(data)
                except json.JSONDecodeError:
                    continue
                yield event
    except httpx.ReadTimeout as exc:
        raise asyncio.TimeoutError("Timeout while waiting for OpenRouter response.") from exc
