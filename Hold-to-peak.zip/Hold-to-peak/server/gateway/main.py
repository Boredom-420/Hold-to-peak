from __future__ import annotations

import asyncio
import base64
import binascii
import logging
import os
import signal
from contextlib import asynccontextmanager
from pathlib import Path
from typing import Any, AsyncIterator, Dict, List

import httpx
import orjson
from fastapi import FastAPI, HTTPException, Response, status
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse, StreamingResponse

from config import current_config, init_config_store, update_config
from openrouter import OpenRouterError, stream_chat_completion
from schemas import ConfigUpdate, SolveRequest

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s %(levelname)s %(name)s: %(message)s",
)
logger = logging.getLogger("gateway")

APP_ROOT = Path(__file__).resolve().parent

MODE_PROMPTS: Dict[str, str] = {
    "auto": (
        "You are Hold-to-Peek, a rapid visual assistant. Provide concise, helpful answers "
        "based on the latest captures and user prompt. Default to English."
    ),
    "solve": (
        "Provide a direct solution or next steps for the problem described. "
        "If you need more detail, ask a short follow-up question."
    ),
    "explain": "Explain the captured content clearly and simply, targeting a curious learner.",
    "translate": "Translate the captured content to English. Preserve critical formatting.",
    "summarize": "Summarize the captured content into key bullet points.",
}


def build_messages(payload: SolveRequest) -> List[Dict[str, Any]]:
    history_messages = [
        {
            "role": turn.role,
            "content": turn.content,
        }
        for turn in payload.history
    ]

    system_prompt = MODE_PROMPTS.get(payload.mode, MODE_PROMPTS["auto"])
    history_messages.insert(
        0,
        {
            "role": "system",
            "content": system_prompt,
        },
    )

    user_content: List[Dict[str, Any]] = []

    if payload.prompt.strip():
        user_content.append({"type": "text", "text": payload.prompt.strip()})

    if payload.ocr_text.strip():
        user_content.append(
            {
                "type": "text",
                "text": f"OCR text:\n{payload.ocr_text.strip()}",
            }
        )

    if payload.spans:
        span_summaries = "\n".join(
            f"- [{span.conf or 0:.2f}] {span.text.strip()}" for span in payload.spans if span.text.strip()
        )
        if span_summaries:
            user_content.append(
                {
                    "type": "text",
                    "text": f"Highlighted spans:\n{span_summaries}",
                }
            )

    images: List[str] = list(payload.images_png_b64)
    if not images and payload.image_png_b64:
        images = [payload.image_png_b64]

    for img_str in images:
        if not img_str:
            continue
        # Validate base64 to provide early feedback if malformed.
        try:
            base64.b64decode(img_str, validate=True)
        except (ValueError, binascii.Error) as exc:
            raise HTTPException(
                status_code=status.HTTP_422_UNPROCESSABLE_ENTITY,
                detail=f"Invalid base64 image payload: {exc}",
            ) from exc

        user_content.append(
            {
                "type": "image_url",
                "image_url": {"url": f"data:image/png;base64,{img_str}"},
            }
        )

    metadata_snippets = []
    for key, value in payload.meta.items():
        if value in (None, "", []):
            continue
        metadata_snippets.append(f"{key} = {value}")
    if metadata_snippets:
        user_content.append(
            {
                "type": "text",
                "text": "Metadata:\n" + "\n".join(metadata_snippets),
            }
        )

    history_messages.append(
        {
            "role": "user",
            "content": user_content or [{"type": "text", "text": "No additional context provided."}],
        }
    )
    return history_messages


@asynccontextmanager
async def lifespan(app: FastAPI):
    logger.info("Initialising gateway lifespan.")
    init_config_store(APP_ROOT)
    async with httpx.AsyncClient(timeout=None) as http_client:
        app.state.http_client = http_client
        yield
    logger.info("Gateway shutdown complete.")


app = FastAPI(
    title="Hold-to-Peek Gateway",
    version="0.4.7",
    lifespan=lifespan,
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)


@app.get("/health")
async def health() -> Dict[str, Any]:
    cfg = current_config()
    return {
        "ok": True,
        "version": app.version,
        "config": {
            "has_api_key": bool(cfg.get("openrouter_api_key")),
            "default_model": cfg.get("default_model"),
        },
    }


@app.get("/config")
async def get_config() -> Dict[str, Any]:
    cfg = current_config()
    masked_key = ""
    api_key = cfg.get("openrouter_api_key", "")
    if api_key:
        masked_key = f"{api_key[:4]}…{api_key[-4:]}" if len(api_key) > 8 else "••••"
    return {
        "openrouter_api_key_masked": masked_key,
        "default_model": cfg.get("default_model", ""),
        "timeout_seconds": cfg.get("timeout_seconds", 120),
    }


@app.put("/config", status_code=status.HTTP_202_ACCEPTED)
async def put_config(update: ConfigUpdate) -> Dict[str, Any]:
    cfg = update_config(update.model_dump(exclude_unset=True))
    logger.info(
        "Config updated: has_api_key=%s, model=%s",
        bool(cfg.get("openrouter_api_key")),
        cfg.get("default_model"),
    )
    return {
        "ok": True,
        "config": {
            "has_api_key": bool(cfg.get("openrouter_api_key")),
            "default_model": cfg.get("default_model"),
            "timeout_seconds": cfg.get("timeout_seconds"),
        },
    }


@app.post("/shutdown")
async def shutdown() -> Dict[str, Any]:
    """
    Trigger a graceful shutdown. Intended for the desktop "kill" hotkey.
    """

    loop = asyncio.get_running_loop()

    def _shutdown() -> None:
        logger.info("Shutdown requested via /shutdown endpoint.")
        os.kill(os.getpid(), signal.SIGINT)

    loop.call_later(0.1, _shutdown)
    return {"ok": True}


async def _stream_solution(
    *,
    payload: SolveRequest,
    http_client: httpx.AsyncClient,
) -> AsyncIterator[bytes]:
    cfg = current_config()
    api_key = payload.api_key or cfg.get("openrouter_api_key")
    model = payload.model or cfg.get("default_model")

    if not api_key:
        yield orjson.dumps({"error": "Missing OpenRouter API key. Update settings and retry."}) + b"\n"
        return

    if not model:
        yield orjson.dumps({"error": "No model configured. Choose a model in settings."}) + b"\n"
        return

    timeout = int(cfg.get("timeout_seconds") or 120)

    messages = build_messages(payload)
    system_prompt = MODE_PROMPTS.get(payload.mode, MODE_PROMPTS["auto"]).strip()
    prompt_buffer = ""
    skipping_prompt = bool(system_prompt)
    accumulated_text: List[str] = []
    finish_reason = None

    try:
        async for event in stream_chat_completion(
            client=http_client,
            api_key=api_key,
            model=model,
            messages=messages,
            timeout=timeout,
        ):
            choices = event.get("choices") or []
            if not choices:
                continue
            choice = choices[0]
            finish_reason = choice.get("finish_reason") or finish_reason
            delta = choice.get("delta") or {}
            content_piece = delta.get("content")
            if content_piece:
                text_to_emit = content_piece
                if skipping_prompt:
                    prompt_buffer += content_piece
                    stripped_buffer = prompt_buffer.lstrip()
                    leading_whitespace_len = len(prompt_buffer) - len(stripped_buffer)
                    if not stripped_buffer:
                        continue
                    if system_prompt.startswith(stripped_buffer):
                        continue
                    if stripped_buffer.startswith(system_prompt):
                        remainder = stripped_buffer[len(system_prompt) :]
                        leading_whitespace = prompt_buffer[:leading_whitespace_len]
                        text_to_emit = leading_whitespace + remainder
                        prompt_buffer = ""
                        skipping_prompt = False
                        if not text_to_emit:
                            continue
                    else:
                        text_to_emit = prompt_buffer
                        prompt_buffer = ""
                        skipping_prompt = False
                accumulated_text.append(text_to_emit)
                yield orjson.dumps({"answer_md": text_to_emit}) + b"\n"
    except asyncio.TimeoutError:
        yield orjson.dumps({"error": "Request timed out waiting for OpenRouter response."}) + b"\n"
        return
    except OpenRouterError as exc:
        yield orjson.dumps({"error": str(exc)}) + b"\n"
        return
    except httpx.HTTPError as exc:
        yield orjson.dumps({"error": f"Networking error: {exc}"}) + b"\n"
        return

    tail: Dict[str, Any] = {"final": True, "finish_reason": finish_reason or "stop"}
    if finish_reason == "length":
        tail["note"] = "Model hit token limit; try removing images or shortening the prompt."
    full_answer = "".join(accumulated_text).strip()
    if system_prompt and full_answer.startswith(system_prompt):
        full_answer = full_answer[len(system_prompt) :].lstrip()
    if full_answer:
        tail["full_answer"] = full_answer
    yield orjson.dumps(tail) + b"\n"


@app.post("/solve")
async def solve(payload: SolveRequest) -> Response:
    if not payload.prompt.strip() and not payload.ocr_text.strip() and not payload.images_png_b64:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Payload must include prompt text, OCR text, or at least one image.",
        )

    http_client: httpx.AsyncClient = app.state.http_client

    if payload.stream:
        logger.info(
            "Streaming solve request mode=%s images=%d prompt_len=%d",
            payload.mode,
            len(payload.images_png_b64) if payload.images_png_b64 else (1 if payload.image_png_b64 else 0),
            len(payload.prompt or ""),
        )
        generator = _stream_solution(payload=payload, http_client=http_client)
        return StreamingResponse(generator, media_type="application/x-ndjson")

    full_answer_parts: List[str] = []
    final_payload: Dict[str, Any] = {}
    async for chunk in _stream_solution(payload=payload, http_client=http_client):
        data = orjson.loads(chunk)
        if data.get("error"):
            raise HTTPException(status_code=status.HTTP_502_BAD_GATEWAY, detail=data["error"])
        if data.get("answer_md"):
            full_answer_parts.append(data["answer_md"])
        if data.get("full_answer"):
            final_payload["full_answer"] = data["full_answer"]
        if data.get("note"):
            final_payload["note"] = data["note"]
        if data.get("final"):
            final_payload["finish_reason"] = data.get("finish_reason", "stop")

    answer_text = final_payload.get("full_answer") or "".join(full_answer_parts).strip()
    response_body = {
        "answer_md": answer_text,
        "note": final_payload.get("note"),
        "finish_reason": final_payload.get("finish_reason", "stop"),
    }
    return JSONResponse(response_body)
