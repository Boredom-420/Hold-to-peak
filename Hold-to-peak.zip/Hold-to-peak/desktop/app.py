
import os, json, requests, traceback, base64, threading, time, webbrowser
from io import BytesIO
from PIL import ImageGrab, Image, ImageTk
import pytesseract
import tkinter as tk
from tkinter import ttk, messagebox
import keyboard

BASE_DIR = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
CONFIG_PATH = os.path.join(BASE_DIR, "config", "app.config.json")
SECRETS_PATH = os.path.join(BASE_DIR, "config", "user.secrets.json")
LOG_PATH = os.path.join(BASE_DIR, "desktop", "last_run.log")
GATEWAY_URL = "http://127.0.0.1:8787"
APP_VERSION = "0.4.0"

def log(msg):
    try:
        with open(LOG_PATH, "a", encoding="utf-8") as f:
            f.write(str(msg) + "\n")
    except Exception:
        pass

with open(CONFIG_PATH, "r", encoding="utf-8") as f:
    CFG = json.load(f)

def load_secrets():
    try:
        with open(SECRETS_PATH, "r", encoding="utf-8") as f:
            return json.load(f)
    except Exception:
        return {}

def save_secrets(d):
    try:
        os.makedirs(os.path.dirname(SECRETS_PATH), exist_ok=True)
        with open(SECRETS_PATH, "w", encoding="utf-8") as f:
            json.dump(d, f, indent=2)
    except Exception as e:
        log("Failed to save secrets: " + str(e))

class HotkeyMgr:
    def __init__(self, app):
        self.app = app
        self.capture = CFG["hotkeys"]["capture"].lower()
        self.toggle  = CFG["hotkeys"]["ui_toggle"].lower()
        self.kill    = CFG["hotkeys"]["kill"].lower()
        self.regd = False
    def register(self):
        if self.regd:
            keyboard.unhook_all_hotkeys()
        keyboard.add_hotkey(self.capture, self.app._hotkey_capture_wrapper, suppress=False, trigger_on_release=False)
        keyboard.add_hotkey(self.toggle,  lambda: self.app.after(0, self.app.toggle_visibility), suppress=False, trigger_on_release=False)
        keyboard.add_hotkey(self.kill,    lambda: self.app.after(0, self.app.kill_now), suppress=False, trigger_on_release=False)
        self.regd = True
    def set(self, capture=None, toggle=None, kill=None):
        if capture: self.capture = capture.lower()
        if toggle:  self.toggle = toggle.lower()
        if kill:    self.kill = kill.lower()
        self.register()

class App(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title(f"Hold-to-Peek v{APP_VERSION} — Built by Boredom")
        self.geometry(f"{CFG['ui']['window']['width']}x{CFG['ui']['window']['height']}")
        self.minsize(CFG['ui']['window']['min_width'], CFG['ui']['window']['min_height'])
        self.protocol("WM_DELETE_WINDOW", self.hide_window)

        secrets = load_secrets()

        # Session state
        self.history = []
        self.memory_turns = tk.IntVar(value=int(secrets.get("memory_turns", CFG.get("memory",{}).get("turns",6))))
        self.wait_to_send = tk.BooleanVar(value=bool(secrets.get("wait_to_send", CFG.get("wait_to_send", True))))
        try:
            cfg_scale = float(CFG.get("display_scale", 1.0))
        except Exception:
            cfg_scale = 1.0
        try:
            default_scale = float(secrets.get("display_scale", cfg_scale))
        except Exception:
            default_scale = cfg_scale
        self.display_scale = tk.DoubleVar(value=max(0.1, default_scale))
        self.queue = []   # list of dicts: {"img": PIL.Image, "ocr": str, "b64": str|None, "thumb_tk": PhotoImage}
        updates_cfg = CFG.get("updates", {})
        self.update_manifest_url = updates_cfg.get("version_url", "")
        self.update_download_fallback = updates_cfg.get("download_url", "")
        self.update_status = tk.StringVar(value="Checking for updates...")
        self._update_checking = False
        self.latest_download_url: str | None = None
        self.update_notes: str | None = None

        # Tabs
        self.tabs = ttk.Notebook(self); self.tabs.pack(fill="both", expand=True, padx=8, pady=6)

        # Capture tab
        cap_tab = ttk.Frame(self.tabs); self.tabs.add(cap_tab, text="Capture")
        cap_bar = ttk.Frame(cap_tab); cap_bar.pack(fill="x", padx=6, pady=6)
        self.mode = tk.StringVar(value="auto")
        ttk.Label(cap_bar, text="Mode").pack(side="left")
        ttk.OptionMenu(cap_bar, self.mode, "auto", "auto", "solve", "explain", "translate", "summarize").pack(side="left", padx=6)
        ttk.Button(cap_bar, text="Capture (Shift+C)", command=self.start_capture).pack(side="right")
        ttk.Button(cap_bar, text="Clear Output", command=lambda: self.output.delete("1.0","end")).pack(side="right", padx=6)

        # Staging row
        stage = ttk.Labelframe(cap_tab, text="Staging (add context or more captures before sending)")
        stage.pack(fill="x", padx=6, pady=6)
        self.stage_info = ttk.Label(stage, text="Queue: 0 captures")
        self.stage_info.pack(side="left", padx=6)
        ttk.Button(stage, text="Send queued now", command=self.send_queue).pack(side="right")
        ttk.Button(stage, text="Clear queue", command=self.clear_queue).pack(side="right", padx=6)
        self.stage_context = tk.Text(cap_tab, height=4, wrap="word")
        self.stage_context.pack(fill="x", padx=6, pady=(0,6))

        # Thumbnails strip (scrollable)
        thumbs_frame = ttk.Frame(cap_tab)
        thumbs_frame.pack(fill="x", padx=6, pady=4)
        self.thumbs_canvas = tk.Canvas(thumbs_frame, height=120, highlightthickness=0)
        self.thumbs_scroll = ttk.Scrollbar(thumbs_frame, orient="horizontal", command=self.thumbs_canvas.xview)
        self.thumbs_inner = ttk.Frame(self.thumbs_canvas)
        self.thumbs_inner.bind("<Configure>", lambda e: self.thumbs_canvas.configure(scrollregion=self.thumbs_canvas.bbox("all")))
        self.thumbs_canvas.create_window((0,0), window=self.thumbs_inner, anchor="nw")
        self.thumbs_canvas.configure(xscrollcommand=self.thumbs_scroll.set)
        self.thumbs_canvas.pack(fill="x", side="top")
        self.thumbs_scroll.pack(fill="x", side="bottom")

        # Live preview of last capture
        preview_row = ttk.Frame(cap_tab); preview_row.pack(fill="x", padx=6, pady=(0,6))
        self.preview_label = ttk.Label(preview_row, text="")
        self.preview_label.pack(side="left")
        self.preview_img_ref = None

        # Output
        self.output = tk.Text(cap_tab, wrap="word"); self.output.pack(fill="both", expand=True, padx=6, pady=6)

        # Chat tab
        chat_tab = ttk.Frame(self.tabs); self.tabs.add(chat_tab, text="Chat")
        chat_top = ttk.Frame(chat_tab); chat_top.pack(fill="x", padx=6, pady=6)
        self.chat_mode = tk.StringVar(value="auto")
        ttk.Label(chat_top, text="Mode").pack(side="left")
        ttk.OptionMenu(chat_top, self.chat_mode, "auto", "auto", "solve", "explain", "translate", "summarize").pack(side="left", padx=6)
        self.chat_entry = tk.Text(chat_tab, height=6, wrap="word"); self.chat_entry.pack(fill="x", padx=6, pady=(0,6))
        chat_btns = ttk.Frame(chat_tab); chat_btns.pack(fill="x", padx=6, pady=6)
        ttk.Button(chat_btns, text="Send", command=self.start_chat).pack(side="right")
        ttk.Button(chat_btns, text="Clear Output", command=lambda: self.chat_output.delete("1.0","end")).pack(side="right", padx=6)
        ttk.Button(chat_btns, text="Clear Input", command=lambda: self.chat_entry.delete("1.0","end")).pack(side="left")
        self.chat_output = tk.Text(chat_tab, wrap="word"); self.chat_output.pack(fill="both", expand=True, padx=6, pady=6)

        # Settings tab
        settings = ttk.Frame(self.tabs); self.tabs.add(settings, text="Settings")
        s1 = ttk.Labelframe(settings, text="Provider")
        s1.pack(fill="x", padx=8, pady=8)
        ttk.Label(s1, text="Model").grid(row=0, column=0, sticky="w", padx=6, pady=4)
        self.model_var = tk.StringVar(value=secrets.get("openrouter_model", "openrouter/auto"))
        ttk.Entry(s1, textvariable=self.model_var, width=32).grid(row=0, column=1, padx=6, pady=4)
        ttk.Label(s1, text="API Key").grid(row=0, column=2, sticky="w", padx=6, pady=4)
        self.key_var = tk.StringVar(value=secrets.get("openrouter_api_key", ""))
        ttk.Entry(s1, textvariable=self.key_var, width=40, show="*").grid(row=0, column=3, padx=6, pady=4)

        s2 = ttk.Labelframe(settings, text="Memory & Flow")
        s2.pack(fill="x", padx=8, pady=8)
        ttk.Label(s2, text="Memory (turns)").grid(row=0, column=0, sticky="w", padx=6, pady=4)
        self.memory_spin = ttk.Spinbox(s2, from_=0, to=30, width=5, textvariable=self.memory_turns)
        self.memory_spin.grid(row=0, column=1, padx=6, pady=4)
        self.wait_chk = ttk.Checkbutton(s2, text="Wait to send (queue captures & add context first)", variable=self.wait_to_send)
        self.wait_chk.grid(row=0, column=2, columnspan=2, padx=6, pady=4, sticky="w")
        ttk.Label(s2, text="Display scale").grid(row=1, column=0, sticky="w", padx=6, pady=4)
        self.display_scale_spin = ttk.Spinbox(s2, from_=0.5, to=3.0, increment=0.05, width=6, textvariable=self.display_scale)
        self.display_scale_spin.grid(row=1, column=1, padx=6, pady=4, sticky="w")
        ttk.Label(s2, text="1.0 keeps default DPI").grid(row=1, column=2, columnspan=2, padx=6, pady=4, sticky="w")

        updates_frame = ttk.Labelframe(settings, text="Updates")
        updates_frame.pack(fill="x", padx=8, pady=8)
        ttk.Label(updates_frame, textvariable=self.update_status).grid(row=0, column=0, sticky="w", padx=6, pady=4)
        self.update_open_button = ttk.Button(
            updates_frame, text="Open download", state="disabled", command=self.open_update_page
        )
        self.update_open_button.grid(row=0, column=1, padx=6, pady=4)
        ttk.Button(updates_frame, text="Check now", command=self._start_update_check).grid(row=0, column=2, padx=6, pady=4)

        s3 = ttk.Labelframe(settings, text="Hotkeys")
        s3.pack(fill="x", padx=8, pady=8)
        ttk.Label(s3, text="Capture").grid(row=0, column=0, sticky="w", padx=6, pady=4)
        self.hk_capture = tk.StringVar(value=CFG["hotkeys"]["capture"])
        ttk.Entry(s3, textvariable=self.hk_capture, width=16).grid(row=0, column=1, padx=6, pady=4)
        ttk.Label(s3, text="Show/Hide").grid(row=0, column=2, sticky="w", padx=6, pady=4)
        self.hk_toggle = tk.StringVar(value=CFG["hotkeys"]["ui_toggle"])
        ttk.Entry(s3, textvariable=self.hk_toggle, width=16).grid(row=0, column=3, padx=6, pady=4)
        ttk.Label(s3, text="Kill").grid(row=0, column=4, sticky="w", padx=6, pady=4)
        self.hk_kill = tk.StringVar(value=CFG["hotkeys"]["kill"])
        ttk.Entry(s3, textvariable=self.hk_kill, width=16).grid(row=0, column=5, padx=6, pady=4)
        ttk.Button(settings, text="Save Settings", command=self.save_settings).pack(anchor="e", padx=12, pady=8)

        # Hotkeys
        self.capturing = False
        self.last_hotkey_ts = 0.0
        self.hk = HotkeyMgr(self)
        self.hk.register()

        self.withdrawn = False
        self.after(200, self._start_update_check)

    # ---- Window ----
    def hide_window(self):
        self.save_settings(silent=True)
        self.withdraw()
        self.withdrawn = True
    def toggle_visibility(self, *_):
        if self.withdrawn:
            self.deiconify(); self.withdrawn = False; self.lift()
            try: self.focus_force()
            except Exception: pass
        else:
            self.hide_window()

    # ---- Updates ----
    def _start_update_check(self, *_):
        if self._update_checking:
            return
        if not self.update_manifest_url:
            self.update_status.set("Update check disabled (no URL configured).")
            self.update_open_button.configure(state="disabled")
            return
        self._update_checking = True
        self.update_status.set("Checking for updates...")
        self.update_open_button.configure(state="disabled")
        threading.Thread(target=self._check_updates, daemon=True).start()

    def _check_updates(self):
        try:
            response = requests.get(self.update_manifest_url, timeout=10)
            response.raise_for_status()
            content_type = (response.headers.get("Content-Type") or "").lower()
            latest = ""
            download = self.update_download_fallback or None
            notes = None
            if "application/json" in content_type:
                data = response.json()
                latest = str(data.get("latest") or data.get("version") or "").strip()
                download = data.get("download_url") or data.get("url") or download
                notes = data.get("notes")
            else:
                latest = response.text.strip()
            if latest and self._is_version_newer(latest, APP_VERSION):
                message = f"Update available: v{latest}"
                self.after(0, lambda: self._on_update_result(message, download, notes, True))
            else:
                message = f"Up to date (v{APP_VERSION})"
                self.after(0, lambda: self._on_update_result(message, None, notes, False))
        except Exception as exc:
            msg = f"Update check failed: {exc.__class__.__name__}"
            self.after(0, lambda: self._on_update_result(msg, None, None, False))

    def _on_update_result(self, message: str, download_url: str | None, notes: str | None, has_update: bool):
        self.update_status.set(message)
        self.latest_download_url = download_url or None
        self.update_notes = notes
        has_link = bool(download_url or self.update_download_fallback)
        state = "normal" if has_update and has_link else "disabled"
        self.update_open_button.configure(state=state)
        self._update_checking = False

    def _version_tuple(self, version: str):
        parts = []
        for chunk in version.split("."):
            chunk = chunk.strip()
            if not chunk:
                parts.append(0)
                continue
            try:
                parts.append(int(chunk))
            except ValueError:
                filtered = "".join(filter(str.isdigit, chunk))
                parts.append(int(filtered) if filtered else 0)
        return tuple(parts)

    def _is_version_newer(self, candidate: str, current: str) -> bool:
        try:
            return self._version_tuple(candidate) > self._version_tuple(current)
        except Exception:
            return candidate.strip() != current.strip()

    def open_update_page(self):
        target = self.latest_download_url or self.update_download_fallback
        if not target:
            return
        try:
            webbrowser.open_new_tab(target)
        except Exception:
            try:
                self.clipboard_clear()
                self.clipboard_append(target)
                messagebox.showinfo("Hold-to-Peek", f"Link copied to clipboard:\n{target}")
            except Exception:
                pass

    # ---- Settings ----
    def save_settings(self, silent=False):
        cap = self.hk_capture.get().strip() or "Shift+C"
        tog = self.hk_toggle.get().strip() or "Shift+`"
        kil = self.hk_kill.get().strip() or "Shift+K"
        self.hk.set(capture=cap, toggle=tog, kill=kil)
        try:
            scale_val = float(self.display_scale.get())
        except Exception:
            scale_val = 1.0
        scale_val = min(3.0, max(0.1, scale_val))
        self.display_scale.set(scale_val)
        save_secrets({
            "openrouter_api_key": self.key_var.get().strip(),
            "openrouter_model": self.model_var.get().strip(),
            "memory_turns": int(self.memory_turns.get()),
            "wait_to_send": bool(self.wait_to_send.get()),
            "display_scale": float(scale_val),
            "hotkeys": {"capture": cap, "ui_toggle": tog, "kill": kil}
        })
        if not silent:
            try: messagebox.showinfo("Saved", "Settings saved.")
            except Exception: pass

    def _headers(self):
        key = self.key_var.get().strip()
        model = self.model_var.get().strip()
        if not key or not model: raise ValueError("OpenRouter API key and model are required. Fill both and click Save.")
        return {"X-OpenRouter-API-Key": key, "X-OpenRouter-Model": model, "Content-Type": "application/json"}

    def _history_tail(self):
        n = int(self.memory_turns.get())
        if n <= 0: return []
        return self.history[-(n*2):]

    # ---- Kill all ----
    def kill_now(self, *_):
        try: requests.post(f"{GATEWAY_URL}/shutdown", timeout=1)
        except Exception: pass
        try: self.save_settings(silent=True)
        except Exception: pass
        try: self.destroy()
        finally:
            os._exit(0)

    # ---- Capture flow ----
    def _dpi_scale(self):
        try:
            base_scale = float(self.tk.call('tk', 'scaling'))
        except Exception:
            base_scale = 1.0
        try:
            override = float(self.display_scale.get())
            if override > 0:
                return base_scale * override
        except Exception:
            pass
        return base_scale
    def _to_screen_pixels(self, overlay, x, y):
        scale = self._dpi_scale()
        ox, oy = overlay.winfo_rootx(), overlay.winfo_rooty()
        return int(ox + x * scale), int(oy + y * scale)

    def _set_preview(self, pil_img):
        try:
            max_w = 260
            w, h = pil_img.size
            if w > max_w:
                ratio = max_w / float(w)
                pil_img = pil_img.resize((int(w*ratio), int(h*ratio)), Image.LANCZOS)
            img_tk = ImageTk.PhotoImage(pil_img)
            self.preview_label.configure(image=img_tk)
            self.preview_label.image = img_tk
            self.preview_img_ref = img_tk
        except Exception as e:
            log("Preview failed: " + str(e))

    def _hotkey_capture_wrapper(self):
        now = time.time()
        if (now - self.last_hotkey_ts) < 0.35 or self.capturing:
            return
        self.last_hotkey_ts = now
        self.after(0, self.start_capture)

    def start_capture(self):
        if self.capturing:
            return
        self.capturing = True
        overlay = tk.Toplevel(self)
        overlay.attributes("-fullscreen", True)
        overlay.attributes("-alpha", 0.25)
        overlay.configure(bg="black")
        canvas = tk.Canvas(overlay, cursor="cross", bg="black", highlightthickness=0)
        canvas.pack(fill="both", expand=True)

        state = {"x0": None, "y0": None, "rect": None}

        def on_press(e):
            state["x0"], state["y0"] = e.x, e.y
            if state["rect"]: canvas.delete(state["rect"])
            state["rect"] = canvas.create_rectangle(e.x, e.y, e.x, e.y, outline="white", width=2)

        def on_drag(e):
            if state["rect"]: canvas.coords(state["rect"], state["x0"], state["y0"], e.x, e.y)

        def end_capture(e):
            try:
                x0, y0 = state["x0"], state["y0"]
                x1, y1 = e.x, e.y
                sx0, sy0 = self._to_screen_pixels(overlay, x0, y0)
                sx1, sy1 = self._to_screen_pixels(overlay, x1, y1)
                bbox = (min(sx0,sx1), min(sy0,sy1), max(sx0,sx1), max(sy0,sy1))
            finally:
                overlay.destroy()
                self.capturing = False
            self._handle_capture(bbox)

        canvas.bind("<ButtonPress-1>", on_press)
        canvas.bind("<B1-Motion>", on_drag)
        canvas.bind("<ButtonRelease-1>", end_capture)

    def _make_thumb(self, img):
        w, h = img.size
        max_h = 96
        if h > max_h:
            ratio = max_h / float(h)
            img = img.resize((int(w*ratio), int(h*ratio)), Image.LANCZOS)
        return ImageTk.PhotoImage(img)

    def _refresh_thumbs(self):
        # clear
        for child in self.thumbs_inner.winfo_children():
            child.destroy()
        # rebuild rows
        for idx, item in enumerate(self.queue):
            frame = ttk.Frame(self.thumbs_inner, padding=4, relief="groove")
            frame.grid(row=0, column=idx, padx=4, pady=4, sticky="n")

            # thumb
            lbl = ttk.Label(frame, image=item.get("thumb_tk"))
            lbl.pack()
            lbl.bind("<Button-1>", lambda e, i=idx: self._set_preview(self.queue[i]["img"].copy()))

            # controls
            ctr = ttk.Frame(frame); ctr.pack(fill="x", pady=2)
            ttk.Label(ctr, text=f"#{idx+1}").pack(side="left")
            ttk.Button(ctr, text="Up", width=4, command=lambda i=idx: self._move_up(i)).pack(side="left", padx=2)
            ttk.Button(ctr, text="Down", width=6, command=lambda i=idx: self._move_down(i)).pack(side="left", padx=2)
            ttk.Button(ctr, text="X", width=3, command=lambda i=idx: self._remove_item(i)).pack(side="right")

    def _move_up(self, i):
        if i <= 0: return
        self.queue[i-1], self.queue[i] = self.queue[i], self.queue[i-1]
        self._refresh_thumbs()
        self.stage_info.configure(text=f"Queue: {len(self.queue)} captures")

    def _move_down(self, i):
        if i >= len(self.queue)-1: return
        self.queue[i+1], self.queue[i] = self.queue[i], self.queue[i+1]
        self._refresh_thumbs()
        self.stage_info.configure(text=f"Queue: {len(self.queue)} captures")

    def _remove_item(self, i):
        try:
            self.queue.pop(i)
        except Exception:
            return
        self._refresh_thumbs()
        self.stage_info.configure(text=f"Queue: {len(self.queue)} captures")

    def _handle_capture(self, bbox):
        img = ImageGrab.grab(bbox=bbox)
        self._set_preview(img.copy())
        try: ocr_text = pytesseract.image_to_string(img)
        except Exception as e: ocr_text = ""; log("OCR error: " + str(e))
        include_image = (len((ocr_text or '').strip()) < 3)
        img_b64 = None
        if include_image:
            buf = BytesIO(); img.save(buf, format="PNG"); img_b64 = base64.b64encode(buf.getvalue()).decode("utf-8")

        if self.wait_to_send.get():
            thumb_tk = self._make_thumb(img.copy())
            self.queue.append({"img": img, "ocr": ocr_text, "b64": img_b64, "thumb_tk": thumb_tk})
            self.stage_info.configure(text=f"Queue: {len(self.queue)} captures")
            self._refresh_thumbs()
            return

        # Immediate single-shot
        self._send_payload(
            prompt_text="",
            ocr_text=ocr_text,
            images_b64=[img_b64] if img_b64 else [],
            meta={"bbox": bbox, "ui_lang": "en", "source": "capture"},
        )

    def clear_queue(self):
        self.queue = []
        self.stage_context.delete("1.0","end")
        self.stage_info.configure(text="Queue: 0 captures")
        self._refresh_thumbs()

    def send_queue(self):
        if not self.queue and not self.stage_context.get("1.0","end").strip():
            try: messagebox.showwarning("Nothing to send","Queue is empty.")
            except Exception: pass
            return
        ocr_parts = []
        images_b64 = []
        for item in self.queue:
            ocr_val = (item.get("ocr") or "").strip()
            if ocr_val:
                ocr_parts.append(ocr_val)
            if item.get("b64"):
                images_b64.append(item["b64"])
        prompt_text = self.stage_context.get("1.0","end").strip()
        ocr_text = "\n\n---\n\n".join(ocr_parts)
        meta = {
            "source": "staged",
            "queue_len": len(self.queue),
            "context_present": bool(prompt_text),
            "wait_to_send": True,
        }
        self._send_payload(prompt_text=prompt_text, ocr_text=ocr_text, images_b64=images_b64, meta=meta)
        self.clear_queue()

    def _send_payload(self, prompt_text, ocr_text, images_b64, meta):
        self.output.delete("1.0", "end"); self.output.insert("end", "## Streaming...\n\n")
        try:
            headers = self._headers()
        except Exception as e:
            self.output.insert("end", f"[error] {e}\n")
            return
        key = self.key_var.get().strip()
        model = self.model_var.get().strip()
        images_b64 = [img for img in images_b64 if img]
        payload_meta = dict(meta or {})
        payload_meta.setdefault("wait_to_send", bool(self.wait_to_send.get()))
        payload_meta.setdefault("mode", self.mode.get())
        payload_meta["capture_count"] = len(images_b64)
        try:
            payload_meta["display_scale"] = float(self.display_scale.get())
        except Exception:
            payload_meta["display_scale"] = 1.0
        payload = {
            "mode": self.mode.get(),
            "prompt": prompt_text or "",
            "ocr_text": ocr_text or "",
            "spans": [],
            "image_png_b64": images_b64[0] if images_b64 else None,
            "images_png_b64": images_b64,
            "meta": payload_meta,
            "history": self._history_tail(),
            "api_key": key,
            "model": model,
        }
        acc = []
        try:
            with requests.post(f"{GATEWAY_URL}/solve", headers=headers, json=payload, stream=True, timeout=300) as r:
                if r.status_code >= 400:
                    try: detail = r.json().get("detail", r.text)
                    except Exception: detail = r.text
                    self.output.insert("end", f"[error] {r.status_code} {detail}\n"); return
                for line in r.iter_lines():
                    if not line: continue
                    try:
                        obj = json.loads(line.decode("utf-8"))
                        if obj.get("error"):
                            self.output.insert("end", f"\n\n[error] {obj['error']}\n")
                            return
                        if "answer_md" in obj and obj["answer_md"]:
                            acc.append(obj["answer_md"])
                            self.output.insert("end", obj["answer_md"]); self.output.see("end")
                        if obj.get("final"):
                            note = obj.get("note")
                            if note: self.output.insert("end", f"\n\n> {note}\n")
                            self.output.see("end")
                    except Exception as e:
                        self.output.insert("end", "\n[stream chunk]\n"); log(e)
        except Exception as e:
            self.output.insert("end", f"\n\n[error] {e}\n"); log(traceback.format_exc())
        content_parts = []
        prompt_trim = (prompt_text or "").strip()
        ocr_trim = (ocr_text or "").strip()
        if prompt_trim:
            content_parts.append(prompt_trim)
        if ocr_trim:
            content_parts.append(ocr_trim)
        if images_b64:
            content_parts.append(f"[{len(images_b64)} image(s)]")
        user_entry = "\n\n".join(content_parts) if content_parts else "[image selection]"
        self.history.append({"role":"user","content": user_entry})
        self.history.append({"role":"assistant","content": "".join(acc).strip()})

    # ---- Chat ----
    def start_chat(self):
        text = self.chat_entry.get("1.0","end").strip()
        if not text:
            try: messagebox.showwarning("Empty","Type a message to chat.")
            except Exception: pass
            return
        self.chat_output.delete("1.0","end"); self.chat_output.insert("end","## Chat streaming...\n\n")
        try:
            headers = self._headers()
        except Exception as e:
            self.chat_output.insert("end", f"[error] {e}\n")
            return
        key = self.key_var.get().strip()
        model = self.model_var.get().strip()
        payload = {
            "mode": self.chat_mode.get(),
            "prompt": text,
            "ocr_text": "",
            "spans": [],
            "image_png_b64": None,
            "images_png_b64": [],
            "meta": {"source": "chat"},
            "history": self._history_tail(),
            "api_key": key,
            "model": model,
        }
        try:
            payload["meta"]["display_scale"] = float(self.display_scale.get())
        except Exception:
            payload["meta"]["display_scale"] = 1.0
        acc = []
        try:
            with requests.post(f"{GATEWAY_URL}/solve", headers=headers, json=payload, stream=True, timeout=180) as r:
                if r.status_code >= 400:
                    try: detail = r.json().get("detail", r.text)
                    except Exception: detail = r.text
                    self.chat_output.insert("end", f"[error] {r.status_code} {detail}\n"); return
                for line in r.iter_lines():
                    if not line: continue
                    try:
                        obj = json.loads(line.decode("utf-8"))
                        if obj.get("error"):
                            self.chat_output.insert("end", f"\n\n[error] {obj['error']}\n")
                            return
                        if "answer_md" in obj and obj["answer_md"]:
                            acc.append(obj["answer_md"])
                            self.chat_output.insert("end", obj["answer_md"]); self.chat_output.see("end")
                        if obj.get("final"):
                            note = obj.get("note")
                            if note: self.chat_output.insert("end", f"\n\n> {note}\n")
                            self.chat_output.see("end")
                    except Exception:
                        self.chat_output.insert("end", "\n[stream chunk]\n")
        except Exception as e:
            self.chat_output.insert("end", f"\n\n[error] {e}\n")
        self.history.append({"role":"user","content": text})
        self.history.append({"role":"assistant","content": "".join(acc).strip()})

def main():
    App().mainloop()

if __name__ == "__main__":
    main()
