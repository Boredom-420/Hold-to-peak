import json
from pathlib import Path
from typing import Any, Dict
from threading import RLock

CONFIG_FILENAME = "config.json"


class ConfigStore:
    """Thread-safe helper to persist gateway configuration to disk."""

    _defaults: Dict[str, Any] = {
        "openrouter_api_key": "",
        "default_model": "",
        "timeout_seconds": 120,
    }

    def __init__(self, root: Path) -> None:
        self._path = root / CONFIG_FILENAME
        self._lock = RLock()
        self._data: Dict[str, Any] = {}
        self._load_or_init()

    def _load_or_init(self) -> None:
        with self._lock:
            if self._path.exists():
                try:
                    self._data = json.loads(self._path.read_text(encoding="utf-8"))
                except (json.JSONDecodeError, OSError):
                    self._data = {}
            for key, default_val in self._defaults.items():
                self._data.setdefault(key, default_val)
            self._flush_unlocked()

    def _flush_unlocked(self) -> None:
        self._path.write_text(json.dumps(self._data, indent=2), encoding="utf-8")

    def get(self) -> Dict[str, Any]:
        with self._lock:
            return dict(self._data)

    def update(self, updates: Dict[str, Any]) -> Dict[str, Any]:
        with self._lock:
            dirty = False
            for key, value in updates.items():
                if key in self._defaults and value is not None:
                    if self._data.get(key) != value:
                        self._data[key] = value
                        dirty = True
            if dirty:
                self._flush_unlocked()
            return dict(self._data)


store: ConfigStore | None = None


def init_config_store(root: Path) -> ConfigStore:
    global store
    if store is None:
        store = ConfigStore(root)
    return store


def current_config() -> Dict[str, Any]:
    if store is None:
        raise RuntimeError("Config store not initialised yet.")
    return store.get()


def update_config(updates: Dict[str, Any]) -> Dict[str, Any]:
    if store is None:
        raise RuntimeError("Config store not initialised yet.")
    return store.update(updates)
